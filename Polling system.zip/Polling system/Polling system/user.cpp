#include"look.h"
#include"back.h"
int main()
{
	loadingBar();
	system("CLS");
	about();
	cout << "\t\t\t\t\t ";
	system("pause");
	system("CLS");
	class_admin ad;
	ad.enter("12345-1234567-1", ad);
	class_voter vo;
	//kpk 6 voters 
	vo.enter("kpk_1st", "12345-1234567-1", 23, vo);
	vo.enter("kpk_2nd", "12345-1234567-2", 23, vo);
	vo.enter("kpk_3rd", "12345-1234567-3", 23, vo);
	vo.enter("kpk_4th", "12345-1234567-4", 23, vo);
	vo.enter("kpk_5th", "12345-1234567-5", 23, vo);
	vo.enter("kpk_6th", "12345-1234567-6", 23, vo);
	//FATA 6 voter
	vo.enter("fata_1st", "22345-1234567-1", 23, vo);
	vo.enter("fata_2nd", "22345-1234567-2", 23, vo);
	vo.enter("fata_3rd", "22345-1234567-3", 23, vo);
	vo.enter("fata_4th", "22345-1234567-4", 23, vo);
	vo.enter("fata_5th", "22345-1234567-5", 23, vo);
	vo.enter("fata_6th", "22345-1234567-6", 23, vo);
	//punjab 6 voters
	vo.enter("pun_1st", "32345-1234567-1", 23, vo);
	vo.enter("pun_2nd", "32345-1234567-2", 23, vo);
	vo.enter("pun_3rd", "32345-1234567-3", 23, vo);
	vo.enter("pun_4th", "32345-1234567-4", 23, vo);
	vo.enter("pun_5th", "32345-1234567-5", 23, vo);
	vo.enter("pun_6th", "32345-1234567-6", 23, vo);
	//Sindh 6 voters
	vo.enter("sin_1st", "42345-1234567-1", 23, vo);
	vo.enter("sin_2nd", "42345-1234567-2", 23, vo);
	vo.enter("sin_3rd", "42345-1234567-3", 23, vo);
	vo.enter("sin_4th", "42345-1234567-4", 23, vo);
	vo.enter("sin_5th", "42345-1234567-5", 23, vo);
	vo.enter("sin_6th", "42345-1234567-6", 23, vo);
	//Balochistan 6 voters
	vo.enter("bal_1st", "52345-1234567-1", 23, vo);
	vo.enter("bal_2nd", "52345-1234567-2", 23, vo);
	vo.enter("bal_3rd", "52345-1234567-3", 23, vo);
	vo.enter("bal_4th", "52345-1234567-4", 23, vo);
	vo.enter("bal_5th", "52345-1234567-5", 23, vo);
	vo.enter("bal_6th", "52345-1234567-6", 23, vo);
	//Islamabad 6 voters
	vo.enter("isl_1st", "62345-1234567-1", 23, vo);
	vo.enter("isl_2nd", "62345-1234567-2", 23, vo);
	vo.enter("isl_3rd", "62345-1234567-3", 23, vo);
	vo.enter("isl_4th", "62345-1234567-4", 23, vo);
	vo.enter("isl_5th", "62345-1234567-5", 23, vo);
	vo.enter("isl_6th", "62345-1234567-6", 23, vo);
	//Gilgit-Baltistan 6 voters
	vo.enter("gil_1st", "72345-1234567-1", 23, vo);
	vo.enter("gil_2nd", "72345-1234567-2", 23, vo);
	vo.enter("gil_3rd", "72345-1234567-3", 23, vo);
	vo.enter("gil_4th", "72345-1234567-4", 23, vo);
	vo.enter("gil_5th", "72345-1234567-5", 23, vo);
	vo.enter("gil_6th", "72345-1234567-6", 23, vo);
go_user:
	system("CLS");
	users();
	cout << endl << "\t\t\t\t\t Press crosspanding no : ";
	int sel;
	cin >> sel;
	if (sel == 1) // admin
	{
		string cnic = input_cnic();
		bool check = ad.what(cnic);
		if (check)
		{
		go_admin:
			system("CLS");
			admin();
			cout << endl << "\t\t\t\t\t Press crosspanding no : ";
			int sel;
			cin >> sel;
			if (sel == 1)
			{
			go_m_admin:
				system("CLS");
				manage_administrators();
				cout << endl << "\t\t\t\t\t Press crosspanding no : ";
				int sel;
				cin >> sel;
				if (sel == 1)
				{
					ad.enter(input_cnic(), ad);
					cout << "\t\t\t\t\t";
					system("pause");
					goto go_m_admin;
				}
				else if (sel == 2)
				{
					ad.display();
					cout << "\t\t\t\t\t";
					system("pause");
					goto go_m_admin;
				}
				else if (sel == 3)
				{
					ad.del(input_cnic());
					cout << "\t\t\t\t\t";
					system("pause");
					goto go_m_admin;
				}
				else if (sel == 0)
				{
					goto go_admin;
				}
				else
				{
					cout << "\t\t\t\t\t Invalide choise! ";
					system("pause");
					goto go_m_admin;
				}

			}
			else if (sel == 2)
			{
			go_m_can:
				system("CLS");
				manage_candidates();
				cout << endl << "\t\t\t\t\t Press crosspanding no : ";
				int sel;
				cin >> sel;
				if (sel == 1)
				{
					int a = vo.display_can_req();
					if (a == 0)
					{
						system("pause");
						goto go_m_can;
					}
					cout << endl << "\t\t\t\t\tEnter candidate number you make him/her candidate : ";
					int i;
					cin >> i;
					if (i > a || i == 0)
					{
						goto go_m_can;
					}
					vo.add_can(i);
					system("pause");
					goto go_m_can;
				}
				else if (sel == 2)
				{
					int a = vo.display_can();
					if (a == 0)
					{
						system("pause");
						goto go_m_can;
					}
					cout << endl << "\t\t\t\t\tEnter candidate number to delete candidate : ";
					int i;
					cin >> i;
					if (i == 0)
					{
						goto go_m_can;
					}
					vo.del_can(i);
					system("pause");
					goto go_m_can;
				}
				else if (sel == 0)
				{
					goto go_admin;
				}
				else
				{
					cout << "\t\t\t\t\t Invalide choise! ";
					system("pause");
					goto go_m_can;
				}
			}
			else if (sel == 3)
			{
			go_s_votting:
				system("CLS");
				votting();
				string no = input_cnic();
				if (no == "14206")
				{
					cout << "\t\t\t\t\t Votting is ended now!";
					system("pause");
					goto result;
				}
				if (vo.what_can(no))
				{
					int a = vo.display_vote_can(no);
					if (a == 0)
					{
						system("pause");
						goto go_s_votting;
					}
					go_again:
					cout << endl << "\t\t\t\t\tEnter candidate number you want to vote : ";
					int i;
					cin >> i;
					if (i <= 0 || i > a)
					{
						cout << "\t\t\t\t\t Invalid Entry! ";
						system("pause");
						goto go_again;
					}
					vo.cast_vote(i , no);
					system("pause");
					goto go_s_votting;
				}
				else
				{
					cout << "\t\t\t\t\t For some reason you can not cast a vote! ";
					system("pause");
					goto go_s_votting;
				}
			}
			else if (sel == 5)
			{
			go_m_voter:
				system("CLS");
				manage_voter();
				cout << endl << "\t\t\t\t\t Press crosspanding no : ";
				int sel;
				cin >> sel;
				if (sel == 1)
				{
					string cnic = input_cnic();
					cout << "\t\t\t\t\t Enter your name please : ";
					string name;
					cin >> name;
					cout << "\t\t\t\t\t Enter your age please : ";
					int age;
					cin >> age;
					vo.enter(name, cnic, age, vo);
					system("pause");
					goto go_m_voter;
				}
				else if (sel == 2)
				{
					vo.del(input_cnic());
					system("pause");
					goto go_m_voter;
				}
				else if (sel == 4)
				{
					vo.Search(input_cnic());
					system("pause");
					goto go_m_voter;
				}
				else if (sel == 3)
				{
					vo.display();
					system("pause");
					goto go_m_voter;
				}
				else if (sel == 0)
				{
					goto go_admin;
				}
				else
				{
					cout << "\t\t\t\t\t Invalide choise! ";
					system("pause");
					goto go_m_voter;
				}

			}
			else if (sel == 4)
			{
				result:
				vo.display_result();
				vo.start();
				system("pause");
				goto go_admin;
			}
			else if (sel == 0)
			{
				goto go_user;
			}
			else
			{
				cout << "\t\t\t\t\t Invalide choise! ";
				system("pause");
				goto go_admin;
			}
		}
		else
		{
			cout << "\t\t\t\t\t This CNIC is not exist! ";
			system("pause");
			goto go_user;
		}
	}
	else if (sel == 2)
	{
		string cnic = input_cnic();
		bool check = vo.what(cnic);
		if (check)
		{
		go_voter:
			system("CLS");
			voter();
			cout << endl << "\t\t\t\t\t Press crosspanding no : ";
			int sel;
			cin >> sel;
			if (sel == 1)
			{
				cout << "\t\t\t\t\t Do want to be a candidate? (Y/N) : ";
				string ans;
				cin >> ans;
				if (ans == "Y" || ans == "y")
				{
					vo.can(cnic);
					system("pause");
					goto go_voter;
				}
				else if (ans == "N" || ans == "n")
				{
					goto go_voter;
				}
				else
				{
					cout << "\t\t\t\t\t Invalide choise! ";
					system("pause");
					goto go_voter;
				}
			}
			else if (sel == 2)
			{
				cout << "\t\t\t\t\t Do want to withdraw form candidate? (Y/N) : ";
				string ans;
				cin >> ans;
				if (ans == "Y" || ans == "y")
				{
					vo.notcan(cnic);
					system("pause");
					goto go_voter;
				}
				else if (ans == "N" || ans == "n")
				{
					goto go_voter;
				}
			}
			else if (sel == 0)
			{
				goto go_user;
			}
			else
			{
				cout << "\t\t\t\t\t Invalide choise! ";
				system("pause");
				goto go_voter;
			}
		}
		else
		{
			cout << "\t\t\t\t\t This CNIC is not exist! ";
			system("pause");
			goto go_user;
		}
	}
	else if (sel == 3)
	{
		system("CLS");
		help();
		cout << endl;
		system("pause");
		goto go_user;
	}
	else if (sel == 4)
	{
		system("CLS");
		about();
		cout << endl;
		system("pause");
		goto go_user;
	}
	else if (sel == 0)
	{
		go_end:
		system("CLS");
		cout << endl << endl << endl << endl << endl << endl;
		cout << "\t\t\t\t\tThank you!";
		system("pause");
		return 0;
	}
	else
	{
		cout << "\t\t\t\t\t Invalide choise! ";
		system("pause");
		goto go_user;
	}
	return 0;
}

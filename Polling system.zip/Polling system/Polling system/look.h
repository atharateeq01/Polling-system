#include<iostream>
#include<string>
#include <Windows.h>
using namespace std;
void loadingBar()
{
	system("color 0A");
	char a = 177, b = 219;
	cout << "\n\n\n\n";
	cout << "\n\n\n\n\t\t\t\t\t Loading...\n\n";
	cout << "\t\t\t\t\t";
	for (int i = 0; i < 26; i++)
		cout << a;
	cout << "\r";
	cout << "\t\t\t\t\t";
	for (int i = 0; i < 26; i++)
	{
		cout << b;
		Sleep(300);
	}
	return;
}
void about()
{
	system("color 07");
	char b = 219;
	cout << endl << endl << endl << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 80; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                                        ";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << " Sometime Words isn't perfect for intro but if there is, it's right here";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                                        ";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 80; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                                        ";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 4th line
	{
		cout << b;
	}
	cout << " #           # ####### #         # #      ##    # #       ## #######    ";
	for (int i = 0; i < 4; i++)   // left side bar on 4th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << " #           # #       #       #        #    #  #   #   #  # #          ";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 6th line
	{
		cout << b;
	}
	cout << " #     #     # ####### #      #        #      # #     #    # #######    ";
	for (int i = 0; i < 4; i++)   // left side bar on 6th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << " #   #   #   # #       #       #        #    #  #          # #          ";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << " # #       # # ####### ######    # #      ##    #          # #######    ";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 80; i++)   // midel bar
	{
		cout << b;
	}
	cout << endl << "\t    ";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                                        ";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "\t     Riphah International University                \t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "\t Project name :       Polling system                \t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "\t Developer    :       Athar Ateeq                  \t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "\t SAP id       :         14206                      \t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "\t Semester     :         3rd (section B)             \t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "\t Instructor   :    Sir Rana Marwat Hussain          \t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                                        ";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t    ";
	Sleep(300);
	for (int i = 0; i < 80; i++)   // uper bar
	{
		cout << b;
	}
	return;
}
void users()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "  Welcome to Voting system (-.-)..  ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 4th line
	{
		cout << b;
	}
	cout << "  1.  Administrators                ";
	for (int i = 0; i < 4; i++)   // right side bar on 4th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  2.  Voter                         ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 6th line
	{
		cout << b;
	}
	cout << "  3.  Help                          ";
	for (int i = 0; i < 4; i++)   // right side bar on 6th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "  4.  About                         ";
	for (int i = 0; i < 4; i++)   // right side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "  0.  Exit                          ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // lower bar
	{
		cout << b;
	}
	return;
}
void admin()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "  Welcome to Admin panal (=.=)..    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 4th line
	{
		cout << b;
	}
	cout << "  1.  Manage Administrators         ";
	for (int i = 0; i < 4; i++)   // right side bar on 4th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  2.  Manage Candidates             ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "  3.  Start voting                  ";
	for (int i = 0; i < 4; i++)   // right side bar on 6th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "  4.  Check vote Results            ";
	for (int i = 0; i < 4; i++)   // right side bar on 6th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "  5.  Manage voters                 ";
	for (int i = 0; i < 4; i++)   // right side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "  0.  Logout                        ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // lower bar
	{
		cout << b;
	}
	return;
}
void voter()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "  Welcome to voter panal (=.=)..    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  1.  Register as candidate         ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  2.  Don't want to be candidate    ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "  0.  Logout                        ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // lower bar
	{
		cout << b;
	}
	return;
}
void help()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t";
	for (int i = 0; i < 56; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "      Tension not, Help has arrive (=.=)..      ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 56; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "If you wanna cast a vote but don't have voter id";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 6th line
	{
		cout << b;
	}
	cout << "please contact Administrators and if you are a  ";
	for (int i = 0; i < 4; i++)   // right side bar on 6th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 7th line
	{
		cout << b;
	}
	cout << "voter and want to make yourself a candidate then";
	for (int i = 0; i < 4; i++)   // right side bar on 7th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "open your portal and generate request to be a   ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 9th line
	{
		cout << b;
	}
	cout << "candidate. After that it is up to Administrator ";
	for (int i = 0; i < 4; i++)   // right side bar on 9th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 10th line
	{
		cout << b;
	}
	cout << "to accept that request. If you want to cast a   ";
	for (int i = 0; i < 4; i++)   // right side bar on 10th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 10th line
	{
		cout << b;
	}
	cout << "vote open voter portal and you'll get candidiate";
	for (int i = 0; i < 4; i++)   // right side bar on 10th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 10th line
	{
		cout << b;
	}
	cout << "of your area feel, free to cast we will keep it ";
	for (int i = 0; i < 4; i++)   // right side bar on 10th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 10th line
	{
		cout << b;
	}
	cout << "secret.                                         ";
	for (int i = 0; i < 4; i++)   // right side bar on 10th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 10th line
	{
		cout << b;
	}
	cout << "                                                ";
	for (int i = 0; i < 4; i++)   // right side bar on 10th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 10th line
	{
		cout << b;
	}
	cout << "    Admin Phone # : 0347-8448101                ";
	for (int i = 0; i < 4; i++)   // right side bar on 10th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 10th line
	{
		cout << b;
	}
	cout << "    Admin E-mail : atharateeq01@gmail.com       ";
	for (int i = 0; i < 4; i++)   // right side bar on 10th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                                ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t";
	for (int i = 0; i < 56; i++)   // lower bar
	{
		cout << b;
	}
	return;
}
void manage_administrators()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "    Manage Administrators (-.-)..   ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 4th line
	{
		cout << b;
	}
	cout << "  1. Add Administrator              ";
	for (int i = 0; i < 4; i++)   // right side bar on 4th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  2. Display Administrator          ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  3. Delelet Administrator          ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "  0. Exit                           ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // lower bar
	{
		cout << b;
	}
	return;
}
void manage_candidates()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}

	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "    Manage Candidates (-.-)..       ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}

	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 4th line
	{
		cout << b;
	}
	cout << "  1. Check request for Candidates   ";
	for (int i = 0; i < 4; i++)   // right side bar on 4th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  2. Delelet Candidates             ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "  0. Exit                           ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // lower bar
	{
		cout << b;
	}
	return;
}
void manage_voter()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}

	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "      Manage voter  (-.-)..         ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}

	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 4th line
	{
		cout << b;
	}
	cout << "  1. Add voter                      ";
	for (int i = 0; i < 4; i++)   // right side bar on 4th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  2. Delete voter                   ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 6th line
	{
		cout << b;
	}
	cout << "  3. View all voters                ";
	for (int i = 0; i < 4; i++)   // right side bar on 6th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 6th line
	{
		cout << b;
	}
	cout << "  4. Search voter                   ";
	for (int i = 0; i < 4; i++)   // right side bar on 6th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "  0. Exit                           ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // lower bar
	{
		cout << b;
	}
	return;
}
void votting()
{
	system("color 07");
	char b = 219;
	cout << "\r";
	cout << endl << endl << endl << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // uper bar
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}

	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 2nd line
	{
		cout << b;
	}
	cout << "  Welcome to voter panal (=.=)..    ";
	for (int i = 0; i < 4; i++)   // right side bar on 2nd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // bar on 3rd line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 5th line
	{
		cout << b;
	}
	cout << "  Enter your CNIC you cast vote     ";
	for (int i = 0; i < 4; i++)   // right side bar on 5th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 4; i++)   // left side bar on 8th line
	{
		cout << b;
	}
	cout << "                                    ";
	for (int i = 0; i < 4; i++)   // right side bar on 8th line
	{
		cout << b;
	}
	cout << endl << "\t\t\t\t\t";
	for (int i = 0; i < 44; i++)   // lower bar
	{
		cout << b;
	}
	return;
}

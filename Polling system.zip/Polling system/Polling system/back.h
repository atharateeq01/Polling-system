#include<iostream>
#include<string>
using namespace std;
string check(string a);
class node_voter
{
public:
	string name;
	string cnic;
	int age;
	int can;
	string req;
	int get_vote;
	int cast;
	int did;
	node_voter* link;
};

class class_voter
{
private:
	node_voter*head, *tail;
public:
	class_voter()
	{
		head = NULL;
		tail = NULL;	
	}
	void enter(string name, string cnic, int age, class_voter obj)
	{
		if (obj.what(cnic))
		{
			cout << "\t\t\t\t Already exict in our recoed ";
		}
		else
		{
			if (age >= 18)
			{
				node_voter* pt = new node_voter();
				pt->name = name;
				pt->cnic = cnic;
				pt->age = age;
				pt->can = 0;
				pt->req = "no";
				pt->get_vote = 0;
				pt->cast = 0;
				pt->did = 0;
				pt->link = NULL;
				if (head == NULL)
				{
					head = pt;
					tail = pt;
				}
				else
				{
					tail->link = pt;
					tail = pt;
				}
			}
			else
			{
				cout << "\t\t\t\t Voter age is not enough to cast a vote! " << endl;
			}
		}
	}
	void can(string cnic)
	{
		node_voter*pt;
		pt = head;
		while (pt != NULL)
		{
			if (cnic == pt->cnic)
			{
				if (pt->can == 0)
				{
					pt->req = "yes";
					cout << "\t\t\t\t\tYour request has been generated for candidate! ";
					return;
				}
				else
				{
					cout << "\t\t\t\t\tYou are already a candidate! ";
					return;
				}
			}
			pt = pt->link;
		}
	}
	void notcan(string cnic)
	{
		node_voter*pt;
		pt = head;
		while (pt != NULL)
		{
			if (cnic == pt->cnic)
			{
				if (pt->req == "yes")
				{
					pt->can = 0;
					pt->req = "no";
					cout << "\t\t\t\t\tYour request for candidate is deleteed! ";
				}
			}
			pt = pt->link;
		}
	}
	int display_can_req()
	{
		node_voter*pt = head;
		int i = 0;
		while (pt != NULL)
		{
			if (pt->req == "yes")
			{
				i++;
				cout << "\t\t\t\t\t ===================================" << endl;
				cout << "\t\t\t\t\t Candidtae # " << i << " : " << endl;
				cout << "\t\t\t\t\t    Name : " << pt->name << endl;
				cout << "\t\t\t\t\t ===================================" << endl << endl;
			}
			pt = pt->link;
		}
		if (i == 0)
		{
			cout << "\t\t\t\t\tNo candidates request enter! ";
			return 0;
		}
		cout << "\t\t\t\t\t ===================================" << endl;
		cout << "\t\t\t\t\t press 0 to go back  " << endl;
		cout << "\t\t\t\t\t ===================================" << endl;
		cout << "\t\t\t\t\t ";
		return i;
	}
	int display_vote_can(string cnic) // didplay candidates
	{
		node_voter*pt = head;
		int i = 0;
		while (pt != NULL)
		{
			if (pt->can == 1)
			{
				if (pt->cnic[0] == cnic[0])
				{
					i++;
					cout << "\t\t\t\t\t ===================================" << endl;
					cout << "\t\t\t\t\t Candidtae # " << i << " : " << endl;
					cout << "\t\t\t\t\t    Name : " << pt->name << endl;
					cout << "\t\t\t\t\t ===================================" << endl << endl;
				}
			}
			pt = pt->link;
		}
		if (i == 0)
		{
			cout << "\t\t\t\t\t No candidates has been enter in your area! " ;
			return 0;
		}
		cout << "\t\t\t\t\t ";
		return i;
		system("pause");
	}
	int display_can()
	{
		node_voter*pt = head;
		int i = 0;
		while (pt != NULL)
		{
			if (pt->can == 1)
			{
				i++;
				cout << "\t\t\t\t\t ===================================" << endl;
				cout << "\t\t\t\t\t Candidtae # " << i << " : " << endl;
				cout << "\t\t\t\t\t    Name : " << pt->name << endl;
				cout << "\t\t\t\t\t ===================================" << endl << endl;
			}
			pt = pt->link;
		}
		if (i == 0)
		{
			cout << "\t\t\t\t\tNo candidates has been enter! " ;
			return 0;
		}
		cout << "\t\t\t\t\t ===================================" << endl;
		cout << "\t\t\t\t\t press 0 to go back  " << endl;
		cout << "\t\t\t\t\t ===================================" << endl;
		cout << "\t\t\t\t\t ";
		return i;
		system("pause");
	}
	void add_vote_can(int i)
	{
		node_voter*pt;
		pt = head;
		int a = 1;
		while (pt != NULL)
		{
			if (pt->can == 1)
			{
				if (i == a)
				{
					pt->get_vote = 0;
					return;
				}
				a++;
			}
			pt = pt->link;
		}
		cout << "\t\t\t\t\tThis CNIC is not exsit in our record! " << endl;
	}
	void del_can(int i)
	{
		node_voter*pt;
		pt = head;
		int a = 1;
		while (pt != NULL)
		{
			if (pt->can == 1)
			{
				if (i == a)
				{
					pt->can = 0;
					cout << "\t\t\t\t\t Candidate is deleted! ";
					return;
				}
				a++;
			}
			pt = pt->link;
		}
	}
	void cast_vote(int i, string cnic)
	{
		node_voter*pt;
		pt = head;
		int a = 1;
		while (pt != NULL)
		{
			if (pt->can == 1)
			{
				if (pt->cnic[0] == cnic[0])
				{
					if (i == a)
					{
						pt->get_vote = pt->get_vote + 1;
						return;
					}
					a++;
				}
			}
			pt = pt->link;
		}
	}
	void add_can(int i)
	{
		node_voter*pt;
		pt = head;
		int a = 1;
		while (pt != NULL)
		{
			if (pt->req == "yes")
			{
				if (i == a)
				{
					pt->can = 1;
					pt->req = "no";
					cout << "\t\t\t\t\t\tVoter is candidate now! ";
					return;
				}
				a++;
			}
			pt = pt->link;
		}
		cout << "\t\t\t\t\tAll request has been intertained ..... " << endl;
	}
	void display()
	{
		node_voter*pt = head;
		int i = 1;
		while (pt != NULL)
		{
			cout << "\t\t\t\t\t ===================================" << endl;
			cout << "\t\t\t\t\t voter # " << i << " : " << endl;
			cout << "\t\t\t\t\t    CNIC : " << pt->cnic << endl;
			cout << "\t\t\t\t\t    Name : " << pt->name << endl;
			cout << "\t\t\t\t\t    Age  : " << pt->age << endl;
			cout << "\t\t\t\t\t ===================================" << endl << endl;
			pt = pt->link;
			i++;
		}
		if (i == 1)
		{
			cout << "\t\t\t\t\tNo voter has been enterd exist " << endl;
		}
		cout << "\t\t\t\t\t ";
	}
	void Search(string number)
	{
		node_voter*pt;
		pt = head;
		while (pt != NULL)
		{
			if (number == pt->cnic)
			{
				cout << "\t\t\t\t\t ===================================" << endl;
				cout << "\t\t\t\t\t voter has be found  " << endl;
				cout << "\t\t\t\t\t    CNIC : " << pt->cnic << endl;
				cout << "\t\t\t\t\t    Name : " << pt->name << endl;
				cout << "\t\t\t\t\t    Age  : " << pt->age << endl;
				cout << "\t\t\t\t\t ===================================" << endl << endl;
				return;
			}
			pt = pt->link;
		}
		cout << "\t\t\t\t\tNo voter of this CNIC '" << pt->cnic << " exist " << endl;
		cout << "\t\t\t\t\t ";
	}
	bool what(string number)
	{
		node_voter*tmp;
		tmp = head;
		while (tmp != NULL)
		{
			if (number == tmp->cnic)
			{
				return true;
			}
			tmp = tmp->link;
		}
		return false;
	}
	void del(string w)
	{
		node_voter*pt;
		node_voter*per;
		per = NULL;
		pt = head;
		if (pt != NULL && pt->cnic == w)
		{
			head = head->link;
			delete(pt);
			cout << "\t\t\t\t\t This record has been delete ";
			return;
		}
		while (pt != NULL && pt->cnic != w)
		{
			per = pt;
			pt = pt->link;
		}
		if (pt == NULL)
		{
			cout << "\t\t\t\t\t This record does not exict ";
			return;
		}
		per->link = pt->link;
		cout << "\t\t\t\t\t This record has been delete ";
		delete(pt);
	}
	bool what_can(string number)
	{
		node_voter*tmp;
		tmp = head;
		while (tmp != NULL)
		{
			if (number == tmp->cnic && tmp->cast == 0)
			{
				if (tmp->did == 0)
				{
					tmp->cast == 1;
					tmp->did = 1;
					cout << "\t\t\t\t\t------------------------------------------------" << endl;
					cout << "\t\t\t\t\t Candidates of " << check(number) << " are below" << endl;
					cout << "\t\t\t\t\t------------------------------------------------" << endl << endl;
					return true;
				}
				else
				{
					return false;
				}
			}
			tmp = tmp->link;
		}
		return false;
	}
	void display_result()
	{
		node_voter*pt;
		pt = head;
		char cn[7] = { '1', '2', '3', '4', '5', '6', '7' };
		int a[7] = { 0 , 0 , 0 , 0, 0 , 0, 0 };
		string max_cnic[7];
		for (int i = 0; i <7; i++)
		{
			while (pt != NULL)
			{
				if (pt->cnic[0] == cn[i])
				{
					if (a[i] < pt->get_vote)
					{
						a[i] = pt->get_vote;
						max_cnic[i] = pt->cnic;
					}
				}
				pt = pt->link;
			}
		}
		string cn2[7] = { "1", "2", "3", "4", "5", "6", "7" };
		for (int i = 0; i < 7; i++)
		{
			cout << "\t\t\t\t\t ===================================" << endl;
			cout << "\t\t\t\t\t      Winner of " << check(cn2[i])<<endl;
			cout << "\t\t\t\t\t ===================================" << endl;
			node_voter*tmp;
			tmp = head;
			while (tmp != NULL)
			{
				if (max_cnic[i] == tmp->cnic)
				{
					cout << "\t\t\t\t\t    CNIC : " << tmp->cnic << endl;
					cout << "\t\t\t\t\t    Name : " << tmp->name << endl;
					cout << "\t\t\t\t\t ===================================" << endl << endl;
				}
				tmp = tmp->link;
			}
		}
	}
	
	void start()
	{
		node_voter*pt = head;
		while (pt != NULL)
		{
			pt->can = 0;
			pt->req = "no";
			pt->get_vote = 0;
			pt->cast = 0;
			pt->did = 0;
			pt = pt->link;
			
		}
	}

};

class node_admin
{
public:
	string cnic;
	node_admin* link;
};

class class_admin
{
private:
	node_admin *head, *tail;
public:
	class_admin()
	{
		head = NULL;
		tail = NULL;
	}
	void enter(string cnic, class_admin obj)
	{
		if (obj.what(cnic))
		{
			cout << "\t\t\t\t\t Already exict in our recoed " << endl;
		}
		else
		{
			node_admin* pt = new node_admin;
			pt->cnic = cnic;
			pt->link = NULL;
			if (head == NULL)
			{
				head = pt;
				tail = pt;
			}
			else
			{
				tail->link = pt;
				tail = pt;
			}
			cout << "\t\t\t\t\t New recoed has been added " << endl;
		}
	}
	void display()
	{
		node_admin *pt = head;
		int i = 1;
		while (pt != NULL)
		{
			cout << "\t\t\t\t\t-------------------------------------------" << endl;
			cout << "\t\t\t\t\t Admin # " << i << " is : " << pt->cnic << endl;
			cout << "\t\t\t\t\t-------------------------------------------" << endl;
			pt = pt->link;
			i++;
		}
	}
	void Search(string number)
	{
		node_admin *tmp;
		tmp = head;
		while (tmp != NULL)
		{
			if (number == tmp->cnic)
			{
				cout << "\t\t\t\tAdmin of this CNIC '" << tmp->cnic << "' is exsit " << endl;
				return;
			}
			tmp = tmp->link;
		}
		cout << "\t\t\t\tAdmin of this CNIC '" << tmp->cnic << "' doesn't exsit " << endl;
	}

	bool what(string number)
	{
		node_admin *tmp;
		tmp = head;
		while (tmp != NULL)
		{
			if (number == tmp->cnic)
			{
				return true;
			}
			tmp = tmp->link;
		}
		return false;
	}
	void del(string w)
	{
		node_admin *pt;
		node_admin *per;
		per = NULL;
		pt = head;
		if (w == "12345-1234567-1")
		{
			cout << endl << "\t\t\t\t\t=============================================" << endl;
			cout << "\t\t\t\t\t|| Don't you dare try to delete this admin ||" << endl;
			cout << "\t\t\t\t\t|| you are way out of your League          ||  " << endl;
			cout << "\t\t\t\t\t=============================================" << endl;
			return;
		}
		if (pt != NULL && pt->cnic == w)
		{
			head = head->link;
			delete(pt);
			cout << "\t\t\t\t\t This record has be delete " << endl;
			return;
		}
		while (pt != NULL && pt->cnic != w)
		{
			per = pt;
			pt = pt->link;
		}
		if (pt == NULL)
		{
			cout << "\t\t\t\t\t This record does not exict " << endl;
			return;
		}
		per->link = pt->link;
		cout << "\t\t\t\t\t This record has be delete " << endl;
		delete(pt);
	}
};

string input_cnic()
{
go:
	string cnic;
	cout << "\t\t\t\t\t Enter your CNIC please (xxxxx-xxxxxxx-x) : ";
	cin >> cnic;
	int a = 0, b = 0;
	if (cnic.length() == 15) 
	{
		for (int i = 0; i < cnic.length(); i++) 
		{
			if (isdigit(cnic[i]) == false) 
			{
				a = a + i;
			}
			if (cnic[i] == '-') 
			{
				b = b + i;
			}
		}
		if (a == 18 && b == 18) 
		{
			return cnic;
		}
		else 
		{
			cout << "\t\t\t\t\t invalid entry! " << endl;
			goto go;
		}
	}
	else if (cnic == "14206")
	{
		return cnic;
	}
	else
	{
		cout << "\t\t\t\t\t invalid entry! " << endl;
		goto go;
	}
	return cnic;

}

string check(string a)
{
	int i = a.length();
	if (a[0] == '1')
	{
		return "Khyber Pakhtunkhwa";
	}
	else if (a[0] == '2')
	{
		return "FATA";
	}
	else if (a[0] == '3')
	{
		return "Punjab";
	}
	else if (a[0] == '4')
	{
		return "Sindh";
	}
	else if (a[0] == '5')
	{
		return "Balochistan";
	}
	else if (a[0] == '6')
	{
		return "Islamabad";
	}
	else if (a[0] == '7')
	{
		return "Gilgit-Baltistan";
	}
}
